package pp2017.team10.shared;

public class DoorUsage extends Messages {

	/**
	 * @author Güven, Rasit Matnr: 6019617
	 */
	private static final long serialVersionUID = 1903689929686383967L;
	public boolean door;
	
	public DoorUsage(boolean door){
		this.door = true;
	}
	
}
