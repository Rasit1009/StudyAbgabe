package pp2017.team10.shared;

public class Start extends Messages {

	/**
	 * @author Güven, Rasit Matnr: 6019617
	 */
	private static final long serialVersionUID = 5064319678323944159L;
	
}
